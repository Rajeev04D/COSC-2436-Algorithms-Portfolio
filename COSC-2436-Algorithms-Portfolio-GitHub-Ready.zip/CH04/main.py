def quicksort(values):
    if len(values) <= 1:
        return values

    pivot = values[0]
    less = [item for item in values[1:] if item <= pivot]
    greater = [item for item in values[1:] if item > pivot]

    return quicksort(less) + [pivot] + quicksort(greater)

if __name__ == "__main__":
    data = [10, 5, 2, 3, 7, 6, 9]
    print("Original:", data)
    print("Sorted:", quicksort(data))
