# Chapter 4: Quicksort — Lab Report

## Student Information

- **Name:** Rajeev Oad
- **Date:** May 8, 2026
- **Course:** COSC 2436

## Algorithm Summary

- **How it works:** Quicksort is a divide-and-conquer sorting algorithm. It chooses a pivot, partitions the list into values less than and greater than the pivot, and then recursively sorts the smaller parts.
- **Time complexity:** Average-case time complexity is O(n log n). Worst-case time complexity is O(n²) if the pivot choices are poor.
- **When to use it:** Quicksort is useful for efficiently sorting lists and understanding divide-and-conquer problem solving.

## Test Results

| Input | Sorted Result | Notes |
|---|---|---|
| [10, 5, 2, 3, 7, 6, 9] | [2, 3, 5, 6, 7, 9, 10] | Pivot-based recursive sorting. |

### Sample Program Output

```text
Run the program with:
python main.py
```

## Reflection Questions

1. **What was the main idea of this algorithm or data structure?**
   The main idea of Quicksort is to solve a problem in an organized and efficient way. This lab helped me understand not only how the code works, but also why the algorithm is useful in real programming situations.

2. **How does the time complexity affect performance?**
   The time complexity shows how the algorithm grows as the input size increases. For this chapter, the important complexity point is that average-case time complexity is o(n log n). worst-case time complexity is o(n²) if the pivot choices are poor. This matters because an algorithm that works well on small input may become slow on large input.

3. **What did this lab teach you about algorithm design?**
   This lab showed me that algorithm design is about choosing the right approach for the problem. It also helped me see the difference between simply writing code and writing code that is organized, readable, and efficient.

## Challenges Encountered

One challenge in this lab was making sure the algorithm was explained clearly in plain English instead of only showing the code. I resolved this by focusing on what the algorithm does step by step, when it should be used, and how the Big O complexity affects performance.
