def simple_linear_regression(x_values, y_values):
    n = len(x_values)
    mean_x = sum(x_values) / n
    mean_y = sum(y_values) / n

    numerator = sum((x_values[i] - mean_x) * (y_values[i] - mean_y) for i in range(n))
    denominator = sum((x - mean_x) ** 2 for x in x_values)

    slope = numerator / denominator
    intercept = mean_y - slope * mean_x
    return slope, intercept

def predict(x, slope, intercept):
    return slope * x + intercept

if __name__ == "__main__":
    x = [1, 2, 3, 4, 5]
    y = [2, 4, 5, 4, 5]

    slope, intercept = simple_linear_regression(x, y)
    print("Slope:", round(slope, 2))
    print("Intercept:", round(intercept, 2))
    print("Prediction for x=6:", round(predict(6, slope, intercept), 2))
