# Chapter 12: Regression — Lab Report

## Student Information

- **Name:** Rajeev Oad
- **Date:** May 8, 2026
- **Course:** COSC 2436

## Algorithm Summary

- **How it works:** Regression is a basic machine learning method used to model the relationship between input values and an output value. Simple linear regression fits a straight line to data so it can make predictions.
- **Time complexity:** For a simple direct formula approach, the calculation is O(n) because it processes the data points to compute the slope and intercept.
- **When to use it:** Regression is useful for prediction problems, trend analysis, and understanding relationships between variables.

## Test Results

| Data Points | Slope | Intercept | Prediction for x = 6 |
|---|---:|---:|---:|
| (1,2), (2,4), (3,5), (4,4), (5,5) | 0.6 | 2.2 | 5.8 |

### Sample Program Output

```text
Run the program with:
python main.py
```

## Reflection Questions

1. **What was the main idea of this algorithm or data structure?**
   The main idea of Regression is to solve a problem in an organized and efficient way. This lab helped me understand not only how the code works, but also why the algorithm is useful in real programming situations.

2. **How does the time complexity affect performance?**
   The time complexity shows how the algorithm grows as the input size increases. For this chapter, the important complexity point is that for a simple direct formula approach, the calculation is o(n) because it processes the data points to compute the slope and intercept. This matters because an algorithm that works well on small input may become slow on large input.

3. **What did this lab teach you about algorithm design?**
   This lab showed me that algorithm design is about choosing the right approach for the problem. It also helped me see the difference between simply writing code and writing code that is organized, readable, and efficient.

## Challenges Encountered

One challenge in this lab was making sure the algorithm was explained clearly in plain English instead of only showing the code. I resolved this by focusing on what the algorithm does step by step, when it should be used, and how the Big O complexity affects performance.
