# Chapter 1: Binary Search vs Linear Search — Lab Report

## Student Information

- **Name:** Rajeev Oad
- **Date:** May 8, 2026
- **Course:** COSC 2436

## Algorithm Summary

- **How it works:** This lab compares linear search and binary search. Linear search checks each item one by one until it finds the target, while binary search repeatedly cuts a sorted list in half to narrow the search area.
- **Time complexity:** Linear search is O(n). Binary search is O(log n), but it requires the list to already be sorted.
- **When to use it:** Linear search is useful for small or unsorted lists. Binary search is useful when searching large sorted lists quickly.

## Test Results

| Algorithm | Target | Index Found | Comparisons | Notes |
|---|---:|---:|---:|---|
| Linear Search | 777 | 776 | 777 | Checked values one at a time. |
| Binary Search | 777 | 776 | 9 | Found the value by repeatedly cutting the list in half. |

### Sample Program Output

```text
Run the program with:
python main.py
```

## Reflection Questions

1. **What was the main idea of this algorithm or data structure?**
   The main idea of Binary Search vs Linear Search is to solve a problem in an organized and efficient way. This lab helped me understand not only how the code works, but also why the algorithm is useful in real programming situations.

2. **How does the time complexity affect performance?**
   The time complexity shows how the algorithm grows as the input size increases. For this chapter, the important complexity point is that linear search is o(n). binary search is o(log n), but it requires the list to already be sorted. This matters because an algorithm that works well on small input may become slow on large input.

3. **What did this lab teach you about algorithm design?**
   This lab showed me that algorithm design is about choosing the right approach for the problem. It also helped me see the difference between simply writing code and writing code that is organized, readable, and efficient.

## Challenges Encountered

One challenge in this lab was making sure the algorithm was explained clearly in plain English instead of only showing the code. I resolved this by focusing on what the algorithm does step by step, when it should be used, and how the Big O complexity affects performance.
