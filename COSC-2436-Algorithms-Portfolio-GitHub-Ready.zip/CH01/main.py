import time

def linear_search(values, target):
    comparisons = 0
    for index, value in enumerate(values):
        comparisons += 1
        if value == target:
            return index, comparisons
    return -1, comparisons

def binary_search(values, target):
    low = 0
    high = len(values) - 1
    comparisons = 0

    while low <= high:
        comparisons += 1
        mid = (low + high) // 2
        if values[mid] == target:
            return mid, comparisons
        elif values[mid] < target:
            low = mid + 1
        else:
            high = mid - 1

    return -1, comparisons

if __name__ == "__main__":
    numbers = list(range(1, 1001))
    target = 777

    start = time.perf_counter()
    linear_result = linear_search(numbers, target)
    linear_time = time.perf_counter() - start

    start = time.perf_counter()
    binary_result = binary_search(numbers, target)
    binary_time = time.perf_counter() - start

    print("Linear Search:", linear_result, "time:", linear_time)
    print("Binary Search:", binary_result, "time:", binary_time)
