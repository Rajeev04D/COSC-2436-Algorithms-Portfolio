def selection_sort(values):
    comparisons = 0
    swaps = 0

    for i in range(len(values)):
        min_index = i
        for j in range(i + 1, len(values)):
            comparisons += 1
            if values[j] < values[min_index]:
                min_index = j

        if min_index != i:
            values[i], values[min_index] = values[min_index], values[i]
            swaps += 1

    return values, comparisons, swaps

if __name__ == "__main__":
    data = [64, 25, 12, 22, 11]
    sorted_data, comparisons, swaps = selection_sort(data)
    print("Sorted list:", sorted_data)
    print("Comparisons:", comparisons)
    print("Swaps:", swaps)
