# Chapter 2: Selection Sort — Lab Report

## Student Information

- **Name:** Rajeev Oad
- **Date:** May 8, 2026
- **Course:** COSC 2436

## Algorithm Summary

- **How it works:** Selection sort repeatedly finds the smallest remaining item in the list and places it in the next correct position. It divides the list into a sorted part and an unsorted part.
- **Time complexity:** Selection sort is O(n²) because it uses nested scanning to find the minimum value for each position.
- **When to use it:** It is useful for learning sorting logic, but it is not the best choice for large data sets.

## Test Results

| Input | Sorted Result | Comparisons | Swaps |
|---|---|---:|---:|
| [64, 25, 12, 22, 11] | [11, 12, 22, 25, 64] | 10 | 3 |

### Sample Program Output

```text
Run the program with:
python main.py
```

## Reflection Questions

1. **What was the main idea of this algorithm or data structure?**
   The main idea of Selection Sort is to solve a problem in an organized and efficient way. This lab helped me understand not only how the code works, but also why the algorithm is useful in real programming situations.

2. **How does the time complexity affect performance?**
   The time complexity shows how the algorithm grows as the input size increases. For this chapter, the important complexity point is that selection sort is o(n²) because it uses nested scanning to find the minimum value for each position. This matters because an algorithm that works well on small input may become slow on large input.

3. **What did this lab teach you about algorithm design?**
   This lab showed me that algorithm design is about choosing the right approach for the problem. It also helped me see the difference between simply writing code and writing code that is organized, readable, and efficient.

## Challenges Encountered

One challenge in this lab was making sure the algorithm was explained clearly in plain English instead of only showing the code. I resolved this by focusing on what the algorithm does step by step, when it should be used, and how the Big O complexity affects performance.
