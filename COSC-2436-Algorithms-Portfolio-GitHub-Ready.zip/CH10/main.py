def greedy_truck_packing(items, capacity):
    items = sorted(items, key=lambda item: item["value"] / item["weight"], reverse=True)
    chosen = []
    total_weight = 0
    total_value = 0

    for item in items:
        if total_weight + item["weight"] <= capacity:
            chosen.append(item["name"])
            total_weight += item["weight"]
            total_value += item["value"]

    return chosen, total_weight, total_value

if __name__ == "__main__":
    items = [
        {"name": "Box A", "weight": 4, "value": 40},
        {"name": "Box B", "weight": 3, "value": 50},
        {"name": "Box C", "weight": 5, "value": 60},
        {"name": "Box D", "weight": 2, "value": 30},
    ]

    chosen, weight, value = greedy_truck_packing(items, 7)
    print("Chosen items:", chosen)
    print("Total weight:", weight)
    print("Total value:", value)
