import heapq

def dijkstra(graph, start):
    distances = {node: float("inf") for node in graph}
    distances[start] = 0
    priority_queue = [(0, start)]

    while priority_queue:
        current_distance, current_node = heapq.heappop(priority_queue)

        if current_distance > distances[current_node]:
            continue

        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight

            if distance < distances[neighbor]:
                distances[neighbor] = distance
                heapq.heappush(priority_queue, (distance, neighbor))

    return distances

if __name__ == "__main__":
    graph = {
        "A": {"B": 4, "C": 2},
        "B": {"C": 5, "D": 10},
        "C": {"E": 3},
        "D": {"F": 11},
        "E": {"D": 4},
        "F": {}
    }

    print(dijkstra(graph, "A"))
