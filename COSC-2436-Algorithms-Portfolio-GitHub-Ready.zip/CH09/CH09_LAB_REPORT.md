# Chapter 9: Dijkstra's Algorithm — Lab Report

## Student Information

- **Name:** Rajeev Oad
- **Date:** May 8, 2026
- **Course:** COSC 2436

## Algorithm Summary

- **How it works:** Dijkstra's algorithm finds the shortest path from a starting node to all other nodes in a weighted graph. It repeatedly chooses the unvisited node with the smallest known distance and updates distances to its neighbors.
- **Time complexity:** With a priority queue, Dijkstra's algorithm is usually O((V + E) log V).
- **When to use it:** It is useful for maps, routing, network paths, and any situation where the shortest weighted path is needed and edge weights are nonnegative.

## Test Results

| Start Node | Shortest Distances |
|---|---|
| A | A: 0, B: 4, C: 2, E: 5, D: 9, F: 20 |

### Sample Program Output

```text
Run the program with:
python main.py
```

## Reflection Questions

1. **What was the main idea of this algorithm or data structure?**
   The main idea of Dijkstra's Algorithm is to solve a problem in an organized and efficient way. This lab helped me understand not only how the code works, but also why the algorithm is useful in real programming situations.

2. **How does the time complexity affect performance?**
   The time complexity shows how the algorithm grows as the input size increases. For this chapter, the important complexity point is that with a priority queue, dijkstra's algorithm is usually o((v + e) log v). This matters because an algorithm that works well on small input may become slow on large input.

3. **What did this lab teach you about algorithm design?**
   This lab showed me that algorithm design is about choosing the right approach for the problem. It also helped me see the difference between simply writing code and writing code that is organized, readable, and efficient.

## Challenges Encountered

One challenge in this lab was making sure the algorithm was explained clearly in plain English instead of only showing the code. I resolved this by focusing on what the algorithm does step by step, when it should be used, and how the Big O complexity affects performance.
