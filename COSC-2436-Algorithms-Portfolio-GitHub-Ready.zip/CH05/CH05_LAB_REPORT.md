# Chapter 5: Hash Tables — Lab Report

## Student Information

- **Name:** Rajeev Oad
- **Date:** May 8, 2026
- **Course:** COSC 2436

## Algorithm Summary

- **How it works:** A hash table stores data using key-value pairs. The key is processed by a hash function so the program can quickly locate the matching value.
- **Time complexity:** Average-case lookup, insertion, and deletion are O(1). In the worst case, collisions can make operations slower.
- **When to use it:** Hash tables are useful for fast lookup tasks such as dictionaries, caches, frequency counters, and database-style indexing.

## Test Results

| Input Words | Output |
|---|---|
| apple, banana, apple, orange, banana, apple | {'apple': 3, 'banana': 2, 'orange': 1} |

### Sample Program Output

```text
Run the program with:
python main.py
```

## Reflection Questions

1. **What was the main idea of this algorithm or data structure?**
   The main idea of Hash Tables is to solve a problem in an organized and efficient way. This lab helped me understand not only how the code works, but also why the algorithm is useful in real programming situations.

2. **How does the time complexity affect performance?**
   The time complexity shows how the algorithm grows as the input size increases. For this chapter, the important complexity point is that average-case lookup, insertion, and deletion are o(1). in the worst case, collisions can make operations slower. This matters because an algorithm that works well on small input may become slow on large input.

3. **What did this lab teach you about algorithm design?**
   This lab showed me that algorithm design is about choosing the right approach for the problem. It also helped me see the difference between simply writing code and writing code that is organized, readable, and efficient.

## Challenges Encountered

One challenge in this lab was making sure the algorithm was explained clearly in plain English instead of only showing the code. I resolved this by focusing on what the algorithm does step by step, when it should be used, and how the Big O complexity affects performance.
