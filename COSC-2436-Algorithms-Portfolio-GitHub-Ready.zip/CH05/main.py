def count_words(words):
    counts = {}
    for word in words:
        counts[word] = counts.get(word, 0) + 1
    return counts

if __name__ == "__main__":
    words = ["apple", "banana", "apple", "orange", "banana", "apple"]
    result = count_words(words)
    print(result)
    print("apple count:", result["apple"])
