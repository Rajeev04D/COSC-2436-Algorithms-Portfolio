# Chapter 8: Balanced Trees (AVL) — Lab Report

## Student Information

- **Name:** Rajeev Oad
- **Date:** May 8, 2026
- **Course:** COSC 2436

## Algorithm Summary

- **How it works:** An AVL tree is a self-balancing binary search tree. After insertions or deletions, it uses rotations to keep the tree height balanced.
- **Time complexity:** Search, insertion, and deletion are O(log n) because the tree remains balanced.
- **When to use it:** AVL trees are useful when frequent searching is needed and the data must stay sorted and balanced.

## Test Results

| Inserted Values | Preorder Traversal After Balancing |
|---|---|
| 10, 20, 30, 40, 50, 25 | 30, 20, 10, 25, 40, 50 |

### Sample Program Output

```text
Run the program with:
python main.py
```

## Reflection Questions

1. **What was the main idea of this algorithm or data structure?**
   The main idea of Balanced Trees (AVL) is to solve a problem in an organized and efficient way. This lab helped me understand not only how the code works, but also why the algorithm is useful in real programming situations.

2. **How does the time complexity affect performance?**
   The time complexity shows how the algorithm grows as the input size increases. For this chapter, the important complexity point is that search, insertion, and deletion are o(log n) because the tree remains balanced. This matters because an algorithm that works well on small input may become slow on large input.

3. **What did this lab teach you about algorithm design?**
   This lab showed me that algorithm design is about choosing the right approach for the problem. It also helped me see the difference between simply writing code and writing code that is organized, readable, and efficient.

## Challenges Encountered

One challenge in this lab was making sure the algorithm was explained clearly in plain English instead of only showing the code. I resolved this by focusing on what the algorithm does step by step, when it should be used, and how the Big O complexity affects performance.
