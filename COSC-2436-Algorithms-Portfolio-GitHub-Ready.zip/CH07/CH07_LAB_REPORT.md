# Chapter 7: Binary Trees and Tree Traversal — Lab Report

## Student Information

- **Name:** Rajeev Oad
- **Date:** May 8, 2026
- **Course:** COSC 2436

## Algorithm Summary

- **How it works:** A binary tree is a data structure where each node can have at most two children. Tree traversal visits nodes in a specific order, such as inorder, preorder, or postorder.
- **Time complexity:** Tree traversal is O(n) because each node is visited once.
- **When to use it:** Binary trees are useful for hierarchical data, searching, expression parsing, and organizing sorted values.

## Test Results

| Traversal | Output |
|---|---|
| Inorder | 1, 2, 3, 4, 6 |
| Preorder | 4, 2, 1, 3, 6 |
| Postorder | 1, 3, 2, 6, 4 |

### Sample Program Output

```text
Run the program with:
python main.py
```

## Reflection Questions

1. **What was the main idea of this algorithm or data structure?**
   The main idea of Binary Trees and Tree Traversal is to solve a problem in an organized and efficient way. This lab helped me understand not only how the code works, but also why the algorithm is useful in real programming situations.

2. **How does the time complexity affect performance?**
   The time complexity shows how the algorithm grows as the input size increases. For this chapter, the important complexity point is that tree traversal is o(n) because each node is visited once. This matters because an algorithm that works well on small input may become slow on large input.

3. **What did this lab teach you about algorithm design?**
   This lab showed me that algorithm design is about choosing the right approach for the problem. It also helped me see the difference between simply writing code and writing code that is organized, readable, and efficient.

## Challenges Encountered

One challenge in this lab was making sure the algorithm was explained clearly in plain English instead of only showing the code. I resolved this by focusing on what the algorithm does step by step, when it should be used, and how the Big O complexity affects performance.
