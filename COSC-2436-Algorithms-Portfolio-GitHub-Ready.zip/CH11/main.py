def knapsack(values, weights, capacity):
    n = len(values)
    table = [[0 for _ in range(capacity + 1)] for _ in range(n + 1)]

    for i in range(1, n + 1):
        for w in range(capacity + 1):
            if weights[i - 1] <= w:
                include_item = values[i - 1] + table[i - 1][w - weights[i - 1]]
                exclude_item = table[i - 1][w]
                table[i][w] = max(include_item, exclude_item)
            else:
                table[i][w] = table[i - 1][w]

    return table[n][capacity]

if __name__ == "__main__":
    values = [60, 100, 120]
    weights = [10, 20, 30]
    capacity = 50
    print("Maximum value:", knapsack(values, weights, capacity))
