def factorial(n):
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers.")
    if n == 0 or n == 1:
        return 1
    return n * factorial(n - 1)

def countdown(n):
    if n <= 0:
        print("Done")
        return
    print(n)
    countdown(n - 1)

if __name__ == "__main__":
    print("factorial(5):", factorial(5))
    countdown(5)
