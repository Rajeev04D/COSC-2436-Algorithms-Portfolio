# Chapter 3: Recursion — Lab Report

## Student Information

- **Name:** Rajeev Oad
- **Date:** May 8, 2026
- **Course:** COSC 2436

## Algorithm Summary

- **How it works:** Recursion is a method where a function calls itself to solve smaller versions of the same problem. A recursive function needs a base case so it knows when to stop.
- **Time complexity:** The time complexity depends on the recursive problem. For factorial, the complexity is O(n) because the function makes one call for each number down to 1.
- **When to use it:** Recursion is useful for problems that naturally break into smaller subproblems, such as factorials, tree traversal, and divide-and-conquer algorithms.

## Test Results

| Input | Result | Notes |
|---|---:|---|
| factorial(5) | 120 | Uses recursive multiplication. |
| countdown(5) | 5, 4, 3, 2, 1, Done | Stops at the base case. |

### Sample Program Output

```text
Run the program with:
python main.py
```

## Reflection Questions

1. **What was the main idea of this algorithm or data structure?**
   The main idea of Recursion is to solve a problem in an organized and efficient way. This lab helped me understand not only how the code works, but also why the algorithm is useful in real programming situations.

2. **How does the time complexity affect performance?**
   The time complexity shows how the algorithm grows as the input size increases. For this chapter, the important complexity point is that the time complexity depends on the recursive problem. for factorial, the complexity is o(n) because the function makes one call for each number down to 1. This matters because an algorithm that works well on small input may become slow on large input.

3. **What did this lab teach you about algorithm design?**
   This lab showed me that algorithm design is about choosing the right approach for the problem. It also helped me see the difference between simply writing code and writing code that is organized, readable, and efficient.

## Challenges Encountered

One challenge in this lab was making sure the algorithm was explained clearly in plain English instead of only showing the code. I resolved this by focusing on what the algorithm does step by step, when it should be used, and how the Big O complexity affects performance.
